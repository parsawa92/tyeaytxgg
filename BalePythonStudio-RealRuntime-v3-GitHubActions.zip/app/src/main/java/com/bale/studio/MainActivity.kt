package com.bale.studio

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private lateinit var editor: EditText
    private var selected = "baleio"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18,18,18,18)
        }

        val title = TextView(this).apply {
            text = "Bale Python Studio • Python واقعی"
            textSize = 21f
        }
        root.addView(title)

        val libs = Spinner(this)
        libs.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("baleio", "python-bale-bot"))
        libs.setSelection(0)
        libs.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                selected = if (pos == 0) "baleio" else "python-bale-bot"
                output.text = "کتابخانه انتخاب‌شده: $selected"
            }
        }
        root.addView(libs)

        val install = Button(this).apply { text = "نصب کتابخانه با pip واقعی" }
        install.setOnClickListener {
            val pkg = if (selected == "baleio") "baleio" else "python-bale-bot"
            output.text = "در حال نصب $pkg ..."
            Thread {
                val r = Python.getInstance().getModule("runtime")
                    .callAttr("install_package", pkg).toString()
                runOnUiThread { output.text = r }
            }.start()
        }
        root.addView(install)

        editor = EditText(this).apply {
            minLines = 14
            gravity = android.view.Gravity.TOP
            setText("# کد bot.py را اینجا بنویس\nprint('Bale Python Studio')")
        }
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))

        val run = Button(this).apply { text = "▶ اجرای واقعی Python" }
        run.setOnClickListener {
            output.text = "در حال اجرای Python ..."
            Thread {
                val r = Python.getInstance().getModule("runtime")
                    .callAttr("run_code", editor.text.toString()).toString()
                runOnUiThread { output.text = r }
            }.start()
        }
        root.addView(run)

        output = TextView(this).apply {
            text = "Runtime آماده است."
            setPadding(4,12,4,4)
        }
        root.addView(output)

        setContentView(root)
    }
}
