import subprocess, sys, json

def python_version():
    return sys.version

def run_code(code):
    try:
        compiled = compile(code, "<bot.py>", "exec")
        scope = {"__name__": "__main__"}
        exec(compiled, scope, scope)
        return {"ok": True, "output": "Python code finished."}
    except Exception as e:
        return {"ok": False, "output": f"{type(e).__name__}: {e}"}

def install_package(package):
    try:
        p = subprocess.run(
            [sys.executable, "-m", "pip", "install", package],
            capture_output=True, text=True
        )
        return {"ok": p.returncode == 0, "output": (p.stdout + "\n" + p.stderr)[-12000:]}
    except Exception as e:
        return {"ok": False, "output": str(e)}
